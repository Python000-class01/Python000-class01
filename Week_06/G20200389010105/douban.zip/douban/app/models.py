from sqlalchemy import Column, Integer, String, Float
from flask_sqlalchemy import SQLAlchemy
from app import db

class T1(db.Model):
    __tablename__ = 'book_comments'

    id = db.Column(db.Integer, primary_key=True)
    bc_rating = db.Column(db.Integer)
    bc_content = db.Column(db.String(255))
    bc_sentiment = db.Column(db.Float)
