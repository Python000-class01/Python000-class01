# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import json
from douban.dbhelper import DBHelper
from snownlp import SnowNLP

class DoubanPipeline(object):

    def __init__(self):
        self.file = open('book_comments.json', 'a+', encoding='utf-8')
        self.db = DBHelper()

    def process_item(self, item, spider):
        content = json.dumps(dict(item), ensure_ascii=False) + "\n"
        # 情感分析
        item['bc_sentiment'] = self.get_sentiment_score(item['bc_content'])
        self.file.write(content)
        self.db.insert(item)
        return item

    def close_spider(self, spider):
        self.file.close()

    def get_sentiment_score(self, text):
        if text != '':
            s = SnowNLP(text)
            return s.sentiments
        else:
            return 0
