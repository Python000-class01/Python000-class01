# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DoubanItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()

    bc_rating = scrapy.Field() # 评论分数
    bc_content = scrapy.Field() # 评论内容
    bc_sentiment = scrapy.Field() # 评论内容情感分析结果

